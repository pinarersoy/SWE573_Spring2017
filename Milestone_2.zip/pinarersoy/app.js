var TwitterPackage = require('twitter');

var secret = require("./secret");

var Twitter = new TwitterPackage(secret);

var UK = [""];
var US = [""];
var TR = [""];



Twitter.stream('statuses/filter', { track: ':)' }, function (stream) {

  stream.on('data', function (tweet) {
    if (tweet.user.geo_enabled && tweet.user.geo_enabled != null && tweet.user.location != null) {
      if (tweet.user.location.indexOf("United States") > 0 || tweet.user.location.indexOf("US") > 0) {
        US.push(tweet);
      }
      else if (tweet.user.location.indexOf("UK") > 0 || tweet.user.location.indexOf("United Kingdom" > 0)) {
        UK.push(tweet);
      }
      else if (tweet.user.location.search("Türkiye") > 0 || tweet.user.location.search("Turkey") > 0) {
        TR.push(tweet);
      }
    }

    // console.log(tweet);
  });

  stream.on('error', function (error) {
    console.log(error);
  });
});
