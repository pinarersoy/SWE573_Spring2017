var TwitterPackage = require('twitter');

var secret = require("./secret");

var Twitter = new TwitterPackage(secret);

Twitter.stream('statuses/filter', {track: ':('}, function(stream) {

  stream.on('data', function(tweet) {

    console.log(tweet.text);
  });

  stream.on('error', function(error) {
    console.log(error);
  });
});
